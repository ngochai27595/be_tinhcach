export const jwtConstants = {
  secret: 'ANHLH SECRET',
};

export const ACCOUNT_TYPES = {
  DEFAULT: 0,
};
